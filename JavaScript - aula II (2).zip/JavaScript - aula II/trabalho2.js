for(let i = 1; i < 11; i++){
  console.log("valor de i", i);
}
