// Métodos de Adição e Remoção

let frutas = ["maçã", "banana"];
frutas.push("uva");// Adiciona "uva" ao final do array
console.log(frutas); // ["maçã", "banana", "uva"]

frutas.pop(); // Remove o último elemento do array
console.log(frutas); // ["maçã", "banana"]

frutas.unshift("laranja"); // Adiciona "laranja" ao início do array
console.log(frutas); // ["laranja", "maçã", "banana"]

frutas.shift(); // Remove o primeiro elemento do array
console.log(frutas); // ["maçã", "banana"]

// Métodos de Modificação

// array.splice(início, quantidadeRemover, item1, item2, ...)
let frutas_splice = ["maçã", "banana", "laranja"];
frutas_splice.splice(1, 1); 
// Remove 1 elemento a partir do índice 1
console.log(frutas_splice); // ["maçã", "laranja"]

frutas_splice.splice(1, 0, "morango");
// Adiciona "morango" no índice 1 sem remover nada
console.log(frutas_splice); // ["maçã", "morango", "laranja"]

frutas_splice.splice(0, 1, "uva");
// Remove "maçã" e coloca "uva" no lugar
console.log(frutas_splice); // ["uva", "morango", "laranja"]

//array.fill(valor, início?, fim?)
let numeros_fill = [1, 2, 3, 4, 5];
numeros_fill.fill(0, 1, 4); 
console.log(numeros_fill); // [1, 0, 0, 0, 5]

//reverse()
let letras = ["a", "b", "c"];
letras.reverse();
console.log(letras); // ["c", "b", "a"]

//sort()
let nomes = ["Carlos", "Ana", "Bruno"];
nomes.sort();
console.log(nomes); // ["Ana", "Bruno", "Carlos"]

let numeros = [10, 5, 2];
numeros.sort(); // ordena como strings!
console.log(numeros); // [10, 2, 5] errado!

numeros.sort((a, b) => a - b); // correto para números
console.log(numeros); // [2, 5, 10] certo!

//Métodos de Busca e Verificação
//includes()
[1, 2, 3].includes(2); // true

//indexOf()
["a", "b", "c", "a"].indexOf("a"); // 0

//lastIndexOf()
["a", "b", "c", "a"].lastIndexOf("a"); // 3

//find()
[1, 2, 3, 4].find(n => n > 2); // 3

//findIndex()
[1, 2, 3, 4].findIndex(n => n > 2); // 2

//some()
[1, 2, 3].some(n => n > 2); // true

//every()
[1, 2, 3].every(n => n > 0); // true


// Métodos de Iteração e Transformação
//forEach()
let numeros_forEach = [1, 2, 3];
numeros_forEach.forEach((num, index) => {
    console.log(`Índice ${index}: ${num}`); // Índice 0: 1
});

//map()
let numeros_map = [1, 2, 3];
let quadrados = numeros_map.map(num => num * num);
console.log(quadrados); // [1, 4, 9]

//filter()
let numeros_filter = [1, 2, 3, 4, 5];
let pares = numeros_filter.filter(num => num % 2 === 0);
console.log(pares); // [2, 4]

//reduce()
let numeros_reduce = [1, 2, 3, 4];
let soma = numeros_reduce.reduce((acumulador, num) => acumulador + num, 0);
console.log(soma); // 10


// Métodos de Conversão
//join()
let letras_join = ["a", "b", "c"];
let resultado_join = letras_join.join(", ");
console.log(resultado_join); // "a, b, c"

//toString()
let numeros_toString = [1, 2, 3];
let resultado_toString = numeros_toString.toString();
console.log(resultado_toString); // "1,2,3"