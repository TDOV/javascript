var l = ["Ana", "Bruno", "Carlos", "joão"];
let banana = l.join(";");
console.log(banana);