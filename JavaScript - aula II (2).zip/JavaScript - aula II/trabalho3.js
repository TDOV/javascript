
let i = 10;
do {
  console.log(i);
  i = i - 1;
} while ((i > 0));