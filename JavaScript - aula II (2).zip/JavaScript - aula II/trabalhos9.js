let banana = [1,2,3,4,5]
let kiwi = []

banana.forEach((i) => {
  kiwi.push(i*2);
});
console.log(banana);
console.log(kiwi);