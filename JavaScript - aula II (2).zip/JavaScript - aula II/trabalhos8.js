let morango = ["Roxo","Azul","verde"]
var aux = 1;
for (const aux1 of morango) {
  console.log("a minha cor favorita numero", aux ,"é", aux1)
aux = aux + 1
}