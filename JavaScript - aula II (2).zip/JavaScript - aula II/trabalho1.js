let frutas = ["maçã", "banana", "laranja","kiwi","tangerina"];
frutas.push("doi","itens");
for (let fruta of frutas) {
    console.log(fruta);
}