var l = [2, 2, 2, 2, 2];
var aux = 0;
for (let i = 0; i < l.length; i++) {
  var aux1 = l[i];
  aux = aux1 + aux;
}
console.log(aux);
