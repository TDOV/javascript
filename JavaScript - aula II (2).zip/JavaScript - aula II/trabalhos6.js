var l = [];
for(let i=1;i<21;i++){
l.push(i);
}
for (let banana of l) {
  if(banana % 2 == 0){
    console.log(banana);
  }
}