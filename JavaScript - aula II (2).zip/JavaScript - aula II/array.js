let frutas = ["maçã", "banana", "laranja"];
console.log(frutas[0]); // "maçã"

//mutáveis
frutas[0] = "uva"; 
console.log(frutas); // ["uva", "banana", "laranja"]

//aceitam diferentes tipos de dados
let misto = [42, "texto", true, { nome: "João" }, () => console.log("Olá!")];
console.log(misto[3].nome); // "João"

//propriedade length
let numeros = [1, 2, 3];
console.log(numeros.length); // 3