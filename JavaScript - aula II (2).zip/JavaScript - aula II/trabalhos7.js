let uva = [6.2,9.5,8.5,10];
var aux = 0;
var aux1 = 0;
var aux2 = uva.length;
for (let i = 0 ; i < uva.length;i++) {
  aux = uva[i];
  aux1 = aux1 + aux;
}
var x = 0; 
x = aux1 / aux2;
console.log("a media de notas é", x);