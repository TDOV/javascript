//for
for (let i = 0; i < 5; i++) {
    console.log("Valor de i:", i);
}
// Saída: 0 1 2 3 4

//while
let i_while = 0;
while (i_while < 3) {
    console.log("Número:", i_while);
    i_while++;
}
// Saída: 0 1 2

//do...while
let i_do = 5;
do {
    console.log("Executa pelo menos uma vez:", i_do);
    i_do++;
} while (i_do < 3);
// Saída: 5

//for...of
let frutas = ["maçã", "banana", "laranja"];
for (let fruta of frutas) {
    console.log(fruta);
}
// Saída: maçã banana laranja

//for...in
let pessoa = { nome: "Ana", idade: 25, cidade: "SP" };
for (let chave in pessoa) {
    console.log(chave + ": " + pessoa[chave]);
}
// Saída:
// nome: Ana
// idade: 25
// cidade: SP